package com.hashSet;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class ReadOnlyHashSetDemo {
public static void main(String ar[]){
	Set<String> data=new HashSet<String>();
	data.add("Ratnesh");
	data.add("Ishan");
	data.add("Sanjay");
	data.add("Bhavani");
	data=Collections.unmodifiableSet(data);
	
	printWithIterator(data);
	
	
	Scanner scan=new Scanner(System.in);
	System.out.println("Please enter a name to search");
	String name=scan.next();
	boolean b=data.contains(name);
	System.out.println("Element is found--->"+b);
	
	//boolean b1=data.add(name);
	
	//System.out.println("Element is removed--->"+b1);
}//
private static void printWithIterator(Set<String> input){

	Iterator<String> itr=input.iterator();
	while(itr.hasNext()){
		String element=itr.next();
		//System.out.println("Element is ********"+element);
	}
	
	
	
}
}
