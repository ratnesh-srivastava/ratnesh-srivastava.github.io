package com.hashSet;

import java.util.HashSet;

public class TestEmp {

	public static void main(String ar[]){
		Employee emp1=new Employee(23);
		Employee emp2=new Employee(30);
		Employee emp3=new Employee(33);
		Employee emp4=new Employee(35);
		HashSet<Employee> hs=new HashSet<Employee>();
		hs.add(emp1);hs.add(emp2);hs.add(emp3);hs.add(emp4);
		System.out.println("Hashset size*****"+hs.size());
		System.out.println("hs.contains(new Employee (30)--->"+hs.contains(new Employee (30)));
		System.out.println("hs.remove(new Employee (33)--->"+hs.remove(new Employee (33)));
		System.out.println("Hashset size*****"+hs.size());
	}
}

class Employee{
	int age;
	Employee(int age){
		super();
		this.age=age;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int hashCode(){
		return age;
	}
	public boolean equals(Object obj){
		boolean flag=false;
		Employee emp=(Employee)obj;
		if(emp.age==age){
			flag=true;
			return flag;
		}
		return flag;
	}
}
