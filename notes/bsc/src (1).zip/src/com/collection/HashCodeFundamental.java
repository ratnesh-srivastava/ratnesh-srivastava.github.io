package com.collection;

class User{
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}}

public class HashCodeFundamental {
public static void main(String ar[]){
	User user=new User();
	System.out.println(user.hashCode());
	user =new User();
	System.out.println(user.hashCode());
	System.err.println(user.toString());
	System.err.println(user);
	System.err.println(user.toString());
}
}
