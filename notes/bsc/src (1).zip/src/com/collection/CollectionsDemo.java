package com.collection;

import java.util.*;

public class CollectionsDemo {

    public static void main(String[] args) {

        List  a1 = new ArrayList();
        a1.add("Beginner");
        a1.add("Java");
        a1.add("tutorial");
        System.out.println(" ArrayList Elements");
        System.out.print("\t" + a1);

        List l1 = new LinkedList();
        l1.add("Beginner");
        l1.add("Java");
        l1.add("tutorial");
        System.out.println();
        System.out.println(" LinkedList Elements");
        System.out.print("\t" + l1);

        Set s1 = new HashSet();	// or new TreeSet() will order the elements;
        s1.add("Beginner");
        s1.add("Java");
        s1.add("Java");
        s1.add("tutorial");
        System.out.println();
        System.out.println(" Set Elements");
        System.out.print("\t" + s1);

        Map m1 = new HashMap(); // or new TreeMap() will order based on keys
        m1.put("Windows", "98");
        m1.put("Win", "XP");
        m1.put("Beginner", "Java");
        m1.put("Tutorial", "Site");
        System.out.println();
        System.out.println(" Map Elements");
        System.out.print("\t" + m1);  
    }

}
