package com.collection;

class PCustomer extends Object{
	private String id;
	private String name;
	private String address;
	private String email;
	public PCustomer(String id,String name,String address, String email){
		super();
		this.id=id;
		this.name=name;
		this.address=address;
		this.email=email;
	}
	
	public String printData(){
		System.out.println(" Id ="+id+"name "+name+" Address "+address+"email"+email);
		return super.toString();
	}
}
public class HashCodeDemo {
public static void main(String aa[]){
	PCustomer c1=new PCustomer("1","Stanly","USA","stanly106@gmail.com");
	
	//getClass().getName()+'@'+Integer.toHexString(hashCode());
	System.out.println(" c1 = "+c1.toString());
	PCustomer c2=new PCustomer("2","Trupti","USA","trupti106@gmail.com");
	
	System.out.println(" c2 = "+c2);
}
}
