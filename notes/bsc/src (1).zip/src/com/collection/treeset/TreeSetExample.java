package com.collection.treeset;


import java.util.Set;
import java.util.TreeSet;
import java.util.Iterator;



public class TreeSetExample {


    
    public static void main(String[] args) {

        Set treeSet = new TreeSet();

//        the treeset stores Integer objects into the TreeSet
        for (int i = 0; i < 5; i++) {
            treeSet.add(new Integer(i));
        }
        
//        Since its a Integer Object Set adding any other elements in the Same set will produce a 
//        ClassCastException exception at runtime. 
//        treeSet.add("a string");
        
        System.out.print("The elements of the TreeSet are : ");

        Iterator i = treeSet.iterator();
        while (i.hasNext()) {
            System.out.print(i.next()+"\t");
        }

    }

}
