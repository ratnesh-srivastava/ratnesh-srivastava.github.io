package com.collection.hashmap;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

class GCustomer{
	private int id;
	private String name;
	private String email;
	public GCustomer(int id,String name, String email){
		super();
		this.id=id;
		this.name=name;
		this.email=email;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}

public class WeakHashMapDemo {
public static void main(String ar[]){
	Map<GCustomer,String> whm=new WeakHashMap<GCustomer,String>();
	GCustomer c1=new GCustomer(1,"Ratnesh","write2ratnesh@gmail.com");
	GCustomer c2=new GCustomer(2,"Stanly","stanly106@gmail.com");
	whm.put(c1,c1.getEmail());
	whm.put(c2,c2.getEmail());
	Set<GCustomer> set=whm.keySet();
	/*Iterator itr=set.iterator();
	while(itr.hasNext()){
		Object key=itr.next();
		System.out.println("Key value is "+whm.get(key));
	}*/
	Set set1=whm.entrySet();
	Iterator itr=set1.iterator();
	while(itr.hasNext()){
		//Object key=itr.next();
		System.out.println(itr.next());
	}
	/*c1=null;
	System.gc();
	set=whm.keySet();
	itr=set.iterator();
	while(itr.hasNext()){
		Object key=itr.next();
		System.out.println("Key after c1=null is "+whm.get(key));
	}*/
	
	for(GCustomer cust:set){
		System.out.println(cust.getId()+":"+cust.getName()+":"+cust.getEmail());
	}
	
	
}
}
	
