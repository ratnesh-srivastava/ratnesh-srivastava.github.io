package com.collection.hashmap;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

public class SortingHashMap {
public static void main(String ar[]){
	Map<Customer,String> data=new TreeMap<Customer,String>();
	data.put(new Customer("Ishan"),"28");
	data.put(new Customer("Ratnesh"),"33");
	data.put(new Customer("Bhavani"),"27");
	data.put(new Customer("Sanjay"),"26");
	Collection<String>values=data.values();
	for(String str:values){
		//System.out.println("The age are********"+ str);
	}Set<Customer>keys=data.keySet();
	for(Customer cust:keys){
		System.out.println(cust.getName());
	}}}

class Customer implements Comparable{
	private String name;
Customer(String name){
	super();
	this.name=name;
}	public String getName() {
		return name;
	}	public void setName(String name) {
		this.name = name;	}
	@Override
	public int compareTo(Object obj) {
		Customer cust=(Customer)obj;
		int i=name.compareTo(cust.getName());
		//System.out.println("name  cust.getName() i " +name+ ":"+ cust.getName()+":"+i);
		if(i<0){
			i=1;}
		else if(i>0){
			i=-1;
		}return i;	
		}
}