package com.collection.hashmap;

import java.util.Collection;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
public class SortingHashMapComparator {
public static void main(String str[]){
	Map<CCustomer,String>data=new TreeMap<CCustomer,String>(new MyNameComparator());
	//Map<CCustomer,String>data=new TreeMap<CCustomer,String>();
	data.put(new CCustomer("Ratnesh"),"33");
	data.put(new CCustomer("Ishan"),"22");
	data.put(new CCustomer("Sanjay"),"22");
	data.put(new CCustomer("Bhavani"),"21");
	Collection<String> values=data.values();
	for(String name:values){
	System.out.println(name);	}
	Set<CCustomer>keys=data.keySet();
	for(CCustomer cust:keys){
		System.out.println(cust.getName());
	}}}
class MyNameComparator implements Comparator<CCustomer>{
	@Override
	public int compare(CCustomer o1, CCustomer o2) {
		//System.out.println("o1.getName()--->"+o1.getName()+"o2.getName()------>"+o2.getName());
		return o1.getName().compareTo(o2.getName());
	}}
class CCustomer{
	private String name;
public CCustomer(String name){
	super();
	this.name=name;}
	public String getName() {
		return name;	}
	public void setName(String name) {
		this.name = name;
	}
	}
