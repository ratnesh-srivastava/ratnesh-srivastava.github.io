package com.collection;

import java.util.HashSet;
import java.util.Set;

class Person extends Object{
	private String name;
	private String email;
	public Person(String name, String email){
		super();
		this.name=name;
		this.email=email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int hashCode(){
		return name.hashCode()+email.hashCode();
	}
	public boolean equals(Object obj){
		Person p=(Person)obj;
		if(name.equals(p.getName())&& email.equals(p.getEmail())){
			return true;
		}
		return false;
	}
	
}
public class HashCodeWithObject {
public static  void main(String ar[]){
	Set<Person> personSet=new HashSet<Person>();
	Person p1=new Person("Stanly","stanly106@gmail.com");
	Person p2=new Person("Trupti","trupt123@gmail.com");
	personSet.add(p1);
	boolean b1=personSet.add(p2);
	boolean b2=personSet.add(p2);
	System.out.println(b1);
	/**
	 * If you have different object with same state of information their hash code will be same.
	 */
	Person p3=new Person("Ratnesh","write2ratnesh@gmail.com");
	Person p4=new Person("Ratnesh","write2ratnesh@gmail.com");
	personSet.add(p3);
	System.out.println(" Hash Code of P2 is "+p2.hashCode());
	System.out.println(" Hash Code of P3 is "+p3.hashCode());
	System.out.println(" Hash Code of P4 is "+p4.hashCode());
	
}
}
