package com.collection;

import java.util.Enumeration;
import java.util.Vector;

public class AllKindOfIterations {
public static void main(String ar[]){
	Vector<Integer> v=new Vector<Integer>();
	for(int i=0;i<=10;i++){
		v.addElement(i);
	}
	Enumeration<Integer>e=v.elements();
	while(e.hasMoreElements()){
		Integer i=(Integer)e.nextElement();
		System.out.println(i);
	}
}
}
