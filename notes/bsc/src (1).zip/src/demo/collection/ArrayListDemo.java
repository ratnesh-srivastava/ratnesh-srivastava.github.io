package demo.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {
	
	public static void printList(List<String> inList){
		Iterator<String> it=inList.iterator();
		while(it.hasNext()){
			String element=it.next();
			System.out.println("==="+element);
		}
	}
public static void main(String ar[]){
	List<String> list=new ArrayList<String>(5);
	list.add("Apple");
	list.add("Mango");
	list.add("Orange");
	list.add("Pine Apple");
	list.add("Papaya");
	list.add("Banana");
	
	printList(list);
	
}
}
