package demo.collection;

import java.util.HashSet;
import java.util.Set;

public class HashCodeWithObject {
	
	
	private static void hashCodeMagic1(){
		Person p1=new Person("Ratnesh","write2ratnesh@gmail.com");
		System.out.println("Inside Method p1****** hashcode==="+p1.hashCode());
		Person p2=new Person("Ratnesh1","write2ratnesh@gmail.com");
		
		System.out.println("Inside Method p2****** hashcode==="+p2.hashCode());
	}
public static void main(String ar[]){
	Set<Person> personSet=new HashSet<Person>();
	Person p1=new Person("Ratnesh","write2ratnesh@gmail.com");
	Person p2=new Person("Ratnesh","write2ratnesh@gmail.com");
	personSet.add(p1);
	boolean b1=personSet.add(p2);
	Person p3=new Person("Ishan","write2Ishan@gmail.com");
	personSet.add(p3);
	System.out.println("p2 hashcode==="+p2.hashCode());
	System.out.println("p3 hashcode==="+p3.hashCode());
	for(Person p: personSet){
		System.out.println(p.getEmail());
	}
	boolean b=personSet.contains(p3);
	System.out.println(b);
	hashCodeMagic1();
}

}


class Person extends Object{
	private String name;
	private String email;
	Person(String name,String email){
		super();
		this.name=name;
		this.email=email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int hashCode(){
		return name.hashCode()+email.hashCode();
	}
	public boolean equals(Object obj){
		Person p=(Person)obj;
		if(name.equals(p.getName())&& email.equals(p.getEmail())){
			return true;
		}
		return false;
	}
	
}