package demo.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
public class HashMapDemo {
public static void main(String ar[]){
	Map<String,String> mapdata=new LinkedHashMap<String,String>();
	mapdata.put("11","Ratnesh");
	mapdata.put("22","Ishan");
	mapdata.put("44","Sanjay");
	mapdata.put("33","Bhavani");
	
	Collection<String> values=mapdata.values();
	for(String name:values){
		System.out.println(name);
	}
	Set<String> keys=mapdata.keySet();
	for(String name:keys){
		System.out.println(name);
	}
	System.out.println("Please enter roll no");
	Scanner sca=new Scanner(System.in);
	String rollNo=sca.next();
	String name=mapdata.get(rollNo);
	if(name!=null)
		System.out.println("Name of student is ="+name);
	else
		System.out.println("Sorry roll No ="+rollNo+"does not exists");
	}
}

