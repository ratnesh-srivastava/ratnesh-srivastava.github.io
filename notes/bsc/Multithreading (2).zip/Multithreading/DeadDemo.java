public class DeadDemo
{	public static void main(String args[])
	{
	String s1="Dead";
	String s2="Lock";
	MyThread4 m=new MyThread4(s1,s2);
	MyThread3 m1=new MyThread3(s1,s2);
	}}
class MyThread4 extends Thread
{
	String s1;
	String s2;
	MyThread4(String s1, String s2)
	{
	this.s1=s1;
	this.s2=s2;
	start();
}
	public void run()
	{
		while(true)
		{
		synchronized(s1)
		{
		synchronized(s2)
			{
	System.out.println(s1+s2);		
			}}}}}
class MyThread3 extends Thread
{
	String s1;
	String s2;
	MyThread3(String s1,String s2)
	{
	this.s1=s1;
	this.s2=s2;
	start();
	}
	public void run()
	{
		while(true)
		{
		synchronized(s2)
		{	synchronized(s1)
			{
		System.out.println(s2+s1);
			}}}}}
