class CubbyHole1 {
private int contents;
// This boolean variable added for synchronized producer consumer support
private boolean available = false;
public synchronized int get() {
	 while (available == false) {
	 try {
		 wait();
	} catch (InterruptedException e) { }
	 }
	available = false;
	notifyAll();
 return contents;
 }

public synchronized void put(int value) {
	while (available == true) {
		 try {
		 wait();
		 } catch (InterruptedException e) { }
		 }
		 contents = value;
		 available = true;
		 notifyAll();
}
 }

class Producer1 extends Thread {
	 private CubbyHole1 cubbyhole;
	 private int number;
	
	 public Producer1(CubbyHole1 c, int number) {
	 cubbyhole = c;
	 this.number = number;
	 }
	
	 public void run() {
	 for (int i = 0; i < 10; i++) {
	 cubbyhole.put(i);
	 System.out.println("Producer #" + this.number
	 + " put: " + i);
	 try {
	 sleep((int)(Math.random() * 100));
	 } catch (InterruptedException e) { }
	 }
	 }
	 }

 class Consumer1 extends Thread {
	 private CubbyHole1 cubbyhole;
	private int number;
	
	 public Consumer1(CubbyHole1 c, int number) {
	 cubbyhole = c;
	 this.number = number;
	 }
	
	 public void run() {
	 int value = 0;
	 for (int i = 0; i < 10; i++) {
	 value = cubbyhole.get();
	 System.out.println("Consumer #" + this.number
	 + " got: " + value);
	 }
	 }
	 }

 public class InterThreadSynchronized {
	 
	  public static void main(String[] args) {
	 
	  CubbyHole1 c = new CubbyHole1();
	 
	  Producer1 p1 = new Producer1(c, 1);
	  Consumer1 c1 = new Consumer1(c, 1);
	 
	  p1.start();
	  c1.start();
	  }
	  }