class Print {
	void call(String msg) {
		System.out.print("[" + msg);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println("Interrupted");
		}
		System.out.println("]");
	}
}

class PrintCaller implements Runnable {
	String msg;
	Print target;
	Thread t;

	public PrintCaller(Print targ, String s) {
		target = targ;
		msg = s;
		t = new Thread(this);
		t.start();
	}

	// synchronize calls to call()
	public void run() {
		synchronized (target) { // synchronized block
			target.call(msg);
		}
	}
}

public class ThreadSynchronization {
	public static void main(String args[]) {
		Print target = new Print();
		PrintCaller ob1 = new PrintCaller(target, "Hello");
		PrintCaller ob2 = new PrintCaller(target, "Synchronized");
		PrintCaller ob3 = new PrintCaller(target, "World");

		// wait for threads to end
		try {
			ob1.t.join();
			ob2.t.join();
			ob3.t.join();
		} catch (InterruptedException e) {
			System.out.println("Interrupted");
		}
	}
}
