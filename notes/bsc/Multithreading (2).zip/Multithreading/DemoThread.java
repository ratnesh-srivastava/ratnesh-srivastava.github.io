
class AscendThread implements Runnable{
	int i=0;
	public void run(){
		for(int i=1;i<=10;i++){
			System.out.println(" Ascending value is "+i);
		}
	}
}

class DescendThread implements Runnable{
	int i=0;
	public void run(){
		for(int i=10;i>=1;i--){
			System.out.println(" Descending value is "+i);
		}
	}
}



public class DemoThread {
public static void main(String str[]){
	AscendThread as=new AscendThread();
	DescendThread ds=new DescendThread();
	Thread t1=new Thread(as);
	Thread t2=new Thread(ds);
	t1.start();
	t2.start();
}
}
