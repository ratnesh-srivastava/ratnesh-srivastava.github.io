class MyThread6 extends Thread{
	MyThread6(String s){
		super(s);
		start();

	}

	public void run(){
		for(int i=0;i<3;i++){
	Thread cur=Thread.currentThread();		cur.setPriority(Thread.MAX_PRIORITY);
	int p=cur.getPriority();
	System.out.println("Thread Name  :"+Thread.currentThread().getName());
	System.out.println("Thread Priority  :"+cur);
			}	}}
	class MyThread5 extends Thread{
	MyThread5(String s){
		super(s);
		start();

	}

public void run(){
		for(int i=0;i<3;i++){
			Thread cur=Thread.currentThread();
			cur.setPriority(Thread.MIN_PRIORITY);
			int p=cur.getPriority();
			System.out.println("Thread Name  :"+Thread.currentThread().getName());
			System.out.println("Thread Priority  :"+cur);
			}}}

public class ThreadPriority{
	public static void main(String args[]){	
	MyThread6 m1=new MyThread6("My Thread 1");
	MyThread5 m2=new MyThread5("My Thread 2");
	}}
