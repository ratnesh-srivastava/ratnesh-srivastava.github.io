class MyThread2 extends Thread
{
	MyThread2(String s)
	{
		super(s);
		start();

	}
	
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread Name  :"+Thread.currentThread().getName());
			try
			{
				Thread.sleep(1000);
			}catch(Exception e){}
		}

	}

}


public class MultiThread1
{
	public static void main(String args[])
	{
		System.out.println("Thread Name :"+Thread.currentThread().getName());   
		MyThread2 m1=new MyThread2("My Thread 1");
		MyThread2 m2=new MyThread2("My Thread 2");

	}

}

