class MyThreads implements Runnable
{
	Thread t;
	MyThreads(String s)
	{

		t=new Thread(this,s);
		t.start();

	}
	
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Thread Name  :"+Thread.currentThread().getName());
			try
			{
			Thread.sleep(1000);
			}catch(Exception e){}
		}
	}
}

public class RunnableThread
{
	public static void main(String args[])
	{
		System.out.println("Thread Name :"+Thread.currentThread().getName());   
		MyThreads m1=new MyThreads("My Thread 1");
		MyThreads m2=new MyThreads("My Thread 2");

	}

}
