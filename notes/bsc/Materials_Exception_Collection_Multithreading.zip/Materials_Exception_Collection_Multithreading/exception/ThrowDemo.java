package com.exception;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class ThrowDemo {
public static void main(String ar[])throws NotValidNameException{
	Scanner scan=new Scanner(System.in)	;
	System.out.println(" Please enter your name*********");
	String name=scan.next();
	try{
	if(name.equals("Ishan")){
		//NotValidNameException exe=new NotValidNameException("Ishan is not valid name for my program");
		throw new NotValidNameException("Ishan is not valid name for my program");
	}
	System.out.println("Hello your is = "+name);
}
	
	catch(NotValidNameException e){
		e.printStackTrace();
		System.out.println("Please do not enter name is \"ishan\"");
	}
	catch(Exception e){
		e.printStackTrace();
	}
	System.out.println("End of main");
}
}

class NotValidNameException extends RuntimeException{
	NotValidNameException(String str){
		super(str);
	}
}



	


