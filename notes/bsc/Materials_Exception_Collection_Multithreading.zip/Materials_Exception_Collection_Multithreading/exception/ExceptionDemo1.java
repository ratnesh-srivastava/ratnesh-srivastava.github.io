package com.exception;

public class ExceptionDemo1 {
public static void main(String ar[]){
	
	java.util.Scanner scan=new java.util.Scanner(System.in);
	System.out.println("Please enter first no.");
	int i=scan.nextInt();
	System.out.println("Please enter second no.");
	int j=scan.nextInt();
	try{
	int k=i/j;
	System.out.println("Value of K is ********"+k);
	}
	catch(Exception e){
		e.printStackTrace();
	}
	System.out.println(" Your are done!!!!!");
}
}
