package com.collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListDemo {
	public static void printList(List<String> list){
		for(String str:list){
			System.out.println("1=="+str);
		}
		
		for(int i=0;i<list.size();i++){
			System.out.println(("2 =="+list.get(i)));
		}
		
		Iterator<String> it=(Iterator<String>)list.iterator();
		while(it.hasNext()){
			String element=it.next();
			System.out.println("3=="+element);
		}
		
		ListIterator<String> listIterator=list.listIterator();
		while(listIterator.hasNext()){
			System.out.println("4=="+listIterator.next());
		}
	}
public static void main(String ar[]){
	List<String> list=new LinkedList<String>();
	list.add("Apple");
	list.add("Mango");
	list.add("Orange");
	printList(list);
	
}
}
