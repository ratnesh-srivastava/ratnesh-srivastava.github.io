package com.collection;

public class HashCodeFundamental {
public static void main(String ar[]){
	User user=new User();
	System.out.println(user.hashCode());
	
	user=new User();
	System.out.println(user.hashCode());
	
	user=new User();
	System.out.println(user.hashCode());
	
	System.err.println("Object Representation" +  user.toString());
	System.err.println("Object gets Printed" +user);
}


}


class User{
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
