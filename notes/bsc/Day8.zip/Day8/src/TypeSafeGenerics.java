
import java.util.ArrayList;
import java.util.Iterator;

public class TypeSafeGenerics {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		populateNumbers(list);
		int total = 0;
		for (Integer val : list) {
			total = total + val;
		}
		System.out.println(total);
	}

	private static void populateNumbers(ArrayList<Integer> list) {
		list.add(new Integer(1));
		list.add(new Integer(2));
		// Below line of code produces type safe generics
		 //list.add("hello");
	}
}