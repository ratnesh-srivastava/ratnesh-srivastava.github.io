import java.util.ArrayList;
import java.util.Collection;

class Pair1<E> {
	private E obj1;
	private E obj2;

	public Pair1(E element1, E element2) {
		obj1 = element1;
		obj2 = element2;
	}

	public E getFirstObject() {
		return obj1;
	}

	public E getSecondObject() {
		return obj2;
	}
	
	public static <T> void filter(Collection<T> in, Collection<T> out)
	{
	boolean flag = true;
	for(T obj : in)
	{
	if(flag)
	{
	out.add(obj);
	}
	flag = !flag;
	}
	}
}
public class GenericMethodsUse {
	public static void main(String ar[]){
		// Good usage
		Pair1<Double> aPair 	= new Pair1<Double>(new Double(1), new Double(2.2));
		//System.out.println(aPair.getFirstObject());
		//System.out.println(aPair.getSecondObject());
		
		/*ArrayList<Integer> lst1 = new ArrayList<Integer>();
		lst1.add(1);
		lst1.add(2);
		lst1.add(3);
		ArrayList<Integer> lst2 = new ArrayList<Integer>();
		Pair1.filter(lst1, lst2);
		System.out.println(lst2.size());*/
		
		// Typesafe generic method call
		/*ArrayList<Double> dblist = new ArrayList<Double>();
		Pair1.filter(lst1, dblist);
		System.out.println(dblist.size());*/
		
		ArrayList<Integer> lst3 = new ArrayList<Integer>();
		ArrayList lst = new ArrayList();
		lst.add("hello");
		Pair1.filter(lst, lst3);
		System.out.println(lst3.size());
		//in reality the return type is Object. So, the String "hello" managed to get through without any error.
		System.out.println(lst3.get(0));
		
		for(Integer val: lst3)
		{
		System.out.println(val);
		}
		
}
}
