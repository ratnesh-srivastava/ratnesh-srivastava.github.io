import java.util.ArrayList;
import java.util.Collection;

class Pair2<E> {
	private E obj1;
	private E obj2;

	public Pair2(E element1, E element2) {
		obj1 = element1;
		obj2 = element2;
	}

	public E getFirstObject() {
		return obj1;
	}

	public E getSecondObject() {
		return obj2;
	}
	
	/*public static <T> T max(T obj1, T obj2)
	{
	if (obj1 > obj2) // ERROR
	{
	return obj1;
	}
	return obj2;
	}*/
	/**
	 * Problems
	 * 1. This code style is ugly
	 * 2. consider the case where the cast to Comparable fails
	 */
	/*public static <T> T max(T obj1, T obj2)
	{
	// Not elegant code
	Comparable c1 = (Comparable) obj1;
	Comparable c2 = (Comparable) obj2;
	if (c1.compareTo(c2) > 0)
	{
	return obj1;
	}
	return obj2;
	}*/
	
	/**
	 * Solution:
	 * Since we are so heavily dependent on the type implementing this interface, why not ask the compiler to enforce this. 
	 * That is exactly what upper bounds do for us
	 * The compiler will check to make sure that the parameterized type given when calling this
	   method implements the Comparable interface
	 * 
	 */
	public static <T extends Comparable> T max(T obj1, T obj2)
	{
		if (obj1.compareTo(obj2) > 0)
		{
		return obj1;
		}
		return obj2;
}
}


public class UpperBoundsGeneric {
	public static void main(String ar[]){
		
		Integer num1=new Integer(10);
		Integer num2=new Integer(20);
		Integer num3=Pair2.max(num1, num2);
		System.out.println(" The max of num1: 10 and Num2: 20 are "+"\n"+num3);
	}
}
