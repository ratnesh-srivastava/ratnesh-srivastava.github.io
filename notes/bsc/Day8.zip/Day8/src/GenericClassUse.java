class Pair<E> {
	private E obj1;
	private E obj2;

	public Pair(E element1, E element2) {
		obj1 = element1;
		obj2 = element2;
	}

	public E getFirstObject() {
		return obj1;
	}

	public E getSecondObject() {
		return obj2;
	}
}
public class GenericClassUse {
public static void main(String ar[]){
	// Good usage
	/*Pair<Double> aPair 	= new Pair<Double>(new Double(1), new Double(2.2));
	System.out.println(aPair.getFirstObject());
	System.out.println(aPair.getSecondObject());*/
	
	// Wrong usage
	/*Pair<Double> anotherPair= new Pair<Double>(new Integer(1), new Double(2.2));
	System.out.println(anotherPair.getFirstObject());
	System.out.println(anotherPair.getSecondObject());*/
	
	// Liscov Substitution Usage
	//Pair<Object> objectPair = new Pair<Integer>(new Integer(1), new Integer(2));
	
	// Why the below code is allowed?
	
	Pair objectPair	= new Pair<Integer>(new Integer(1), new Integer(2));
	System.out.println(objectPair.getFirstObject());
	System.out.println(objectPair.getSecondObject());
}
}
