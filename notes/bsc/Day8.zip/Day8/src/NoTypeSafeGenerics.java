
import java.util.ArrayList;
import java.util.Iterator;

public class NoTypeSafeGenerics {
	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		populateNumbers(list);
		int total = 0;
		Iterator iter = list.iterator();
		while (iter.hasNext()) {
			total += ((Integer) (iter.next())).intValue();
		}
		System.out.println(total);
	}

	private static void populateNumbers(ArrayList list) {
		list.add(new Integer(1));
		list.add(new Integer(2));
		list.add("Hello");
	}
}