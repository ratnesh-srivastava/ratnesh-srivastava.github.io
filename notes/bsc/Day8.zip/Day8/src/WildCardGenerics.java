import java.util.ArrayList;
import java.util.Collection;

abstract class Animal {
	/*public void playWith(Collection<Animal> playGroup) {
		System.out.println(" Inside Animal Class*********");	}*/
	/*public void playWith(Collection<?> playGroup) {
		System.out.println(" Inside Animal Class*********");
	}*/
	public void playWith(Collection<? extends Animal> playGroup){
		System.out.println(" Inside Animal Class *********");	}}
class Dog extends Animal {
	/*public void playWith(Collection<Animal> playGroup) {
		System.out.println(" Inside Dog Class *********");	}*/
	/*public void playWith(Collection<?> playGroup) {
		System.out.println(" Inside Dog Class*********");
	}*/
	public void playWith(Collection<? extends Animal> playGroup){
		System.out.println(" Inside Dog Class *********");
	}
}public class WildCardGenerics {
public static void main(String ar[]){
	Collection<Dog> dogs = new ArrayList<Dog>();
	Dog aDog = new Dog();
	//aDog.playWith(dogs); //ERROR because a Collection of Dogs can�t be treated as a Collection of Animals
	//which the playWith() method expects
	
	// To run the above line of code use ?(wild card character) in the above playwith method
	aDog.playWith(dogs);
	
	// Problem : We can also write below lines of code
	ArrayList<Integer> numbers = new ArrayList<Integer>();
	aDog.playWith(numbers);
	
	/**
	 * How can we say that the compiler should allow Collections of 
	 * 	Animal or Collections of any type that extends Animal, but not any Collections of
		other types? This is made possible by the use of upper bounds as shown below:
		public void playWith(Collection<? extends Animal> playGroup)
	 */
	// Now after this change below lines of code will produce errors
	//ArrayList<Integer> numbers = new ArrayList<Integer>();
	//aDog.playWith(numbers);
}
}
