class Animal4 { }
	class Horse4 extends Animal4 { 
		
	}
	
	class TestOverload2 {
		public  void doStuff (Animal4 a) {
		System.out.println (" In the Animal version"); 
		}
		public  void  doStuff(Horse4 h) {
		System.out.println ("In the Horse version"); 
		}
		public static void main(String ar[]){
			TestOverload2 ua = new TestOverload2 ();
			Animal4 animalObj=new Animal4();
			Animal4 horseobj = new Horse4();
			ua.doStuff (animalObj);
			ua.doStuff (horseobj);   
		}
	}
