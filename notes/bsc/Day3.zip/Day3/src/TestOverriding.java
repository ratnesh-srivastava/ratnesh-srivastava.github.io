
public class TestOverriding {   	  
		public static void main(String ar[] ) {
		Animal a = new Animal ( );
		Animal b = new Horse ( ); // Animal ref. but Horse object
			a. eat ( ); // Runs the animal version of eat.
			b. eat ( ); //, Runs the Horse version of eat.
	}
}
	class Animal { public void eat ( ) { System.out.println (" Hi "); }}
	class Horse extends Animal {
		public void eat ( ) { System.out.println (" Horse eating hay");
		}
		public void buck ( ){ }
					}
