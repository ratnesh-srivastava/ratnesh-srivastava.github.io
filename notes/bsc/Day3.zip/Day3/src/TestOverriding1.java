
public class TestOverriding1 {   	  
		public static void main(String ar[] ) {
		Animal1 a = new Animal1 ( );
		Animal1 b = new Horse1 ( ); // Animal ref. but Horse object
			a. eat ( ); // Runs the animal version of eat.
			b. eat ( ); //, Runs the Horse version of eat.
			//a.buck(); // buck is not visible to animal
			//b.buck();// buck is not visible to animal reference
	}
}
	class Animal1 	{ 
		public void eat ( )	{ 
		System.out.println (" Hi "); 
	}
		}
	class Horse1 extends Animal1 {
		public void eat() { System.out.println (" Horse eating hay");
		// can not make private
		}
		public void buck ( ){ }
					}
