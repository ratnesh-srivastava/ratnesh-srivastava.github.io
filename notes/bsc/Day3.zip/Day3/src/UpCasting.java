class Animal7  {
	public void show(){
		System.out.println("Generic Animals");
	}
}
		class Dog7 extends Animal7 {
			public void display(){
				System.out.println("Generic Dogs");
			}
		}

class UpCasting {
public static void main(String ar[]){ 
Dog7 d = new Dog7 ();
		Animal7 a1 = d; // upcast ok with no explicit cast
		a1.show();
		Animal7 a2 = (Animal7) d; // upCast ok with an explicit cast.
		a2.show();
		}
}
