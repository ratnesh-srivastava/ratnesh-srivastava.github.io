
class Anima2 {
		public void eat () throws Exception 
		{  
			System.out.println(" Hi I am in Animal Version");
		} 
		}
	class Overriding2 extends Anima2 {
		public void eat ()//throws Exception { // no exceptions
		{
			System.out.println("ANimal Versionh is overrided");
			}
		
		public static void main (String ar[]) {
				Anima2 a = new Overriding2 ();
				Overriding2 d = new Overriding2 ();
				try{
					d.eat (); // ok
					a.eat (); // Compiler error unreported exception.
                   }
		
		catch(Exception e){
			e.printStackTrace();
			}
		}
		}
	