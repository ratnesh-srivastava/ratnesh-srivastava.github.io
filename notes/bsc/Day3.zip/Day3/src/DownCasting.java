class Animal6 {
	void makeNoise (){
		System.out.println ("Generic Noise");
		}
}
	
class Dog6 extends Animal6 {
		void makeNoise ()
		{ 
			System.out.println ("Bark"); 
			}
		void playDead () 
		{ System.out.println ("roll over"); 
		} 
		}

class DownCasting {
	public static void main(String ar[]){
	Animal6 [] a = { new Animal6 (), new Dog6(), new Animal6 ()};
	for (Animal6 animal :a) { 
		animal.makeNoise ();
	    if (animal instanceof Dog6) {
		   Dog6 d=(Dog6)animal;
	    	d.playDead (); // try to do a Dog behavior }}}
	    	//((Dog6)animal).playDead();// this is substitute of above 2 lines
         }
	}
	}
	}