public class ThisSuper {
			String name;
			ThisSuper (String name) {
			this.name = name; 
			}
			ThisSuper () {
				this (makeRandomName ());
				}
				static String makeRandomName (){
				int x= (int) (Math.random ()*5);
				String name = new String [ ] {"Fluffy", "Fido", "Rave", "Spive", "Give"} [x];
				return name;
				}
		public static void main(String ar[]){
			ThisSuper a = new ThisSuper ();
				System.out.println (a.name);
				ThisSuper b = new ThisSuper ("zeus");
			System.out.println (b.name);

			}
		}	
