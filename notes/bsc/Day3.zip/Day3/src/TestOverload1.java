class Animal3 { }
	class Horse3 extends Animal3 { 
		
	}
	
	class TestOverload1 {
		public  void doStuff (Animal3 a) {
		System.out.println (" In the Animal version"); 
		}
		public  void  doStuff(Horse3 h) {
		System.out.println ("In the Horse version"); 
		}
		public static void main(String ar[]){
			TestOverload1 ua = new TestOverload1 ();
			Animal3 animalObj=new Animal3();
			Horse3 horseobj = new Horse3();
			ua.doStuff (animalObj);
			ua.doStuff (horseobj);   
		}
	}
