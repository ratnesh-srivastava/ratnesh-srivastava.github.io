import java.math.BigDecimal;

  class Foo { 
           String go () {
        	   return null;
           }
}
  
  /*class Bar extends Foo { 
     String go (int x)
       {    return null;
        }
}*/

  
   class Bar extends Foo {
	  Bar go () {
	 // Not legal can�t change only the return type
	 return new Bar();  
	 }
	  }
  
  class Alpha {
	  String doStuff (char c){
	  return null;
	       }
	     }
	  class Beta extends Alpha {
	  Beta dostuff (char c){
	  return new Beta ();
	    
	  }
	  }

