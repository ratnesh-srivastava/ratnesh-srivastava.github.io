class PassByTest 
			{
	public static void main(String ar[]){
			int a = 1;
			PassByTest rt = new PassByTest ();
		System.out.println ("Before Modefy () a = " +  a);
		rt . modify (a);
		System.out.println ("Afte modify ()a =" +  a); 
		}
		void modify (int number){
		 number = number +1;
		System.out.println ("number =" +number);
			}
			}
