class Animal11 {
			public void eat ( ) { } 
			public void printYourself ( ) {
				System.out.println("Usefull printing");
 
				 }
     			}

class Horse11 extends Animal11 {
	public void printYourself () {
	//Take advantage of Animal Code, then add some more
	super. printYourself () ;
	//Invoked the superClass (Animal) code Then to Horse � specific print work hare
	}
}


class SuperUse1{
	public static void main(String ar[]){
		Horse11 h=new Horse11();
		h.printYourself();
	}
}
