class Animal5 {
	void makeNoise (){
		System.out.println ("Generic Noise");
		}
}
	
class Dog5 extends Animal5 {
		void makeNoise ()
		{ 
			System.out.println ("Bark"); 
			}
		void playDead () 
		{ System.out.println ("roll over"); 
		} 
		}

class CastingDemo {
	public static void main(String ar[]){
	Animal5 [] a = { new Animal5 (), new Dog5(), new Animal5 ()};
	for (Animal5 animal :a) { 
		animal.makeNoise ();
	    if (animal instanceof Dog5) {
		   animal.playDead (); // try to do a Dog behavior }}}
         }
	}
	}
	}